# 🚨 ElderCare - Emergency & Wellness Assistant for Elderly

A comprehensive emergency and wellness application designed specifically for elderly users, featuring large, accessible buttons, emergency contacts, medicine reminders, and instant alert systems.

## ✨ Features

### 🚨 Emergency Features
- **SOS Button**: One-touch emergency alert system
- **Emergency Contacts**: Add and manage multiple emergency contacts
- **Primary Contact**: Quick dial to primary emergency contact (+91 7006273804 pre-configured)
- **Emergency Services**: Direct connection to local emergency services
- **Location Sharing**: Automatic location sharing with emergency alerts
- **Alert System**: Visual and audio alerts for emergency situations

### 💊 Wellness Features
- **Medicine Reminders**: Schedule and manage medication reminders
- **Daily Schedule**: Pre-configured wellness routine schedule
- **Health Tips**: Daily health and wellness tips
- **Medicine Tracking**: Track when medications are taken
- **Snooze Function**: Flexible reminder management

### 📱 Accessibility Features
- **Large Buttons**: Extra-large, easy-to-tap buttons
- **High Contrast**: Clear, high-contrast design for visibility
- **Simple Interface**: Clean, uncluttered interface design
- **Voice & Vibration**: Audio and vibration alerts
- **Keyboard Shortcuts**: Easy keyboard navigation (Ctrl+Shift+S for SOS)
- **Screen Reader Support**: Fully accessible for screen readers

### 🔧 Technical Features
- **Offline Support**: Works without internet connection
- **Data Backup**: Export and import user data
- **Responsive Design**: Works on all devices and screen sizes
- **Real-time Sync**: Backend data synchronization
- **Secure Storage**: Encrypted local data storage
- **Push Notifications**: Browser-based push notifications

## 🚀 Quick Start

### Prerequisites
- Node.js 14.0 or higher
- npm or yarn package manager
- Modern web browser with JavaScript enabled

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/eldercare-app.git
   cd eldercare-app
   ```

2. **Install backend dependencies**
   ```bash
   cd backend
   npm install
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env file with your configuration
   ```

4. **Start the backend server**
   ```bash
   npm start
   # For development: npm run dev
   ```

5. **Open the application**
   - Open your browser and navigate to `http://localhost:3000`
   - The frontend will be served automatically

### Alternative: Frontend Only

For testing without backend setup:
1. Open the `frontend/index.html` file directly in your browser
2. The app will work with local storage for data

## 🏗️ Project Structure

```
eldercare-app/
├── frontend/                 # Frontend application
│   ├── index.html           # Main HTML file
│   ├── styles.css           # Styling and design
│   ├── script.js            # Frontend JavaScript
│   └── sw.js               # Service worker for offline support
├── backend/                 # Backend API server
│   ├── server.js           # Main server file
│   ├── package.json        # Node.js dependencies
│   └── .env.example        # Environment configuration
├── docs/                   # Documentation
└── README.md              # This file
```

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the `backend/` directory with the following variables:

```env
# Server Configuration
PORT=3000
NODE_ENV=production

# Emergency Contacts (default)
DEFAULT_PRIMARY_CONTACT=+917006273804
DEFAULT_EMERGENCY_NUMBER=911

# SMS Integration (Twilio - optional)
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=your_twilio_number

# Email Notifications (optional)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password
```

### Customization

1. **Change Emergency Contact**: Modify the `DEFAULT_PRIMARY_CONTACT` in `.env`
2. **Add SMS Alerts**: Configure Twilio credentials for SMS emergency alerts
3. **Customize Styling**: Edit `frontend/styles.css` for visual changes
4. **Add Features**: Extend `backend/server.js` with new API endpoints

## 📱 How to Use

### Emergency Functions
1. **SOS Button**: Press the red SOS button for immediate emergency alert
2. **Call Contacts**: Tap on any contact to call them directly
3. **Emergency Services**: Quick dial to local emergency services

### Managing Contacts
1. Click "Add Contact" to add new emergency contacts
2. Set one contact as "Primary" for quick access
3. Delete contacts using the delete button
4. Export/import contacts for backup

### Medicine Reminders
1. Click "Medicine Reminders" in the Wellness section
2. Add new reminders with medicine name, dosage, and time
3. Receive automatic alerts at scheduled times
4. Mark medicines as taken or snooze reminders

### Settings
1. Access settings through the Settings section
2. Configure your name and phone number
3. Enable/disable notifications and alarms
4. Export data for backup or reset the app

## 🌐 Deployment

### GitHub Pages (Frontend Only)

1. Fork this repository
2. Go to Settings > Pages in your GitHub repository
3. Select "Deploy from a branch" and choose `main` branch
4. Your app will be available at `https://your-username.github.io/eldercare-app`

### Full Backend Deployment

#### Option 1: Heroku
```bash
# Install Heroku CLI
heroku create your-app-name
git push heroku main
heroku config:set NODE_ENV=production
```

#### Option 2: Vercel
```bash
# Install Vercel CLI
npm i -g vercel
vercel --prod
```

#### Option 3: DigitalOcean App Platform
1. Create a new app on DigitalOcean
2. Connect your GitHub repository
3. Configure environment variables
4. Deploy automatically

## 🔒 Security Features

- **Rate Limiting**: Protection against spam requests
- **Input Validation**: All user inputs are validated
- **HTTPS Support**: Secure data transmission
- **Local Storage**: Sensitive data stored locally
- **No Third-party Tracking**: Privacy-focused design

## 🆘 Emergency Protocol

1. **SOS Activation**: When SOS is triggered:
   - All emergency contacts are notified via SMS
   - Location is shared (if permitted)
   - Emergency services can be called automatically
   - Continuous audio and visual alerts

2. **Emergency Contacts**: Pre-configured with:
   - Primary Contact: +91 7006273804
   - Emergency Services: 911 (configurable by country)

3. **Backup Systems**: 
   - Works without internet connection
   - Local data storage
   - Automatic sync when connection restored

## 🤝 Contributing

We welcome contributions! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙋‍♂️ Support

For support, please:
1. Check the [Issues](https://github.com/your-username/eldercare-app/issues) page
2. Create a new issue for bug reports or feature requests
3. Email: support@eldercare-app.com

## 🌟 Acknowledgments

- Designed with love for elderly users
- Accessibility guidelines from WCAG 2.1
- Emergency protocols based on medical best practices
- Built with modern web technologies for reliability

---

**⚠️ Disclaimer**: This app is designed to assist in emergencies but should not replace professional medical advice or emergency services. Always call local emergency services in life-threatening situations.

**🚀 Made with ❤️ for the ElderCare Community**