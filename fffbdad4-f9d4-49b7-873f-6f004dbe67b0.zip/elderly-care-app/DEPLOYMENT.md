# 🚀 ElderCare Deployment Guide

This guide will help you deploy the ElderCare application to various platforms for production use.

## 📋 Table of Contents

1. [Frontend-Only Deployment](#frontend-only-deployment)
2. [Full Stack Deployment](#full-stack-deployment)
3. [Environment Configuration](#environment-configuration)
4. [SMS Integration Setup](#sms-integration-setup)
5. [Domain and SSL Setup](#domain-and-ssl-setup)

---

## 🌐 Frontend-Only Deployment

### Option 1: GitHub Pages (Free & Easy)

1. **Prepare the Repository**
   ```bash
   git clone https://github.com/your-username/eldercare-app.git
   cd eldercare-app
   ```

2. **Configure for GitHub Pages**
   ```bash
   # Create a .nojekyll file
   touch frontend/.nojekyll
   
   # Update base URL in index.html if needed
   # No changes needed for GitHub Pages
   ```

3. **Deploy to GitHub**
   ```bash
   git add .
   git commit -m "Ready for GitHub Pages deployment"
   git push origin main
   ```

4. **Enable GitHub Pages**
   - Go to your repository on GitHub
   - Click Settings > Pages
   - Source: Deploy from a branch
   - Branch: main, folder: /(root)
   - Save and wait 2-5 minutes

5. **Access Your App**
   - URL: `https://your-username.github.io/eldercare-app/`
   - The app will work with local storage only

### Option 2: Netlify (Free with Custom Domain)

1. **Sign up for Netlify**
   - Visit [netlify.com](https://netlify.com)
   - Sign up with GitHub

2. **Create New Site**
   - Click "New site from Git"
   - Choose GitHub repository
   - Build settings:
     - Build command: `echo "No build needed"`
     - Publish directory: `frontend`

3. **Deploy**
   - Click "Deploy site"
   - Your app will be live at a random Netlify URL

4. **Custom Domain (Optional)**
   - Go to Site settings > Domain management
   - Add your custom domain
   - Update DNS records as instructed

### Option 3: Vercel (Free with Automatic HTTPS)

1. **Install Vercel CLI**
   ```bash
   npm i -g vercel
   ```

2. **Deploy**
   ```bash
   cd eldercare-app
   vercel --prod
   ```

3. **Follow the prompts**
   - Link to your project directory
   - Configure settings
   - Deploy to production

---

## 🖥️ Full Stack Deployment

### Option 1: Heroku (Free Tier Available)

1. **Install Heroku CLI**
   ```bash
   # macOS
   brew tap heroku/brew && brew install heroku
   
   # Windows
   # Download from devcenter.heroku.com/articles/heroku-cli
   ```

2. **Prepare for Heroku**
   ```bash
   cd eldercare-app/backend
   npm install
   ```

3. **Create Heroku App**
   ```bash
   heroku create your-eldercare-app
   ```

4. **Set Environment Variables**
   ```bash
   heroku config:set NODE_ENV=production
   heroku config:set PORT=3000
   heroku config:set DEFAULT_PRIMARY_CONTACT=+917006273804
   ```

5. **Add Buildpack for Static Files**
   ```bash
   heroku buildpacks:add heroku/nodejs
   heroku buildpacks:add https://github.com/heroku/heroku-buildpack-static
   ```

6. **Create static.json for frontend**
   ```bash
   cd ..
   echo '{"root": "frontend/", "routes": {"/**": "index.html"}}' > static.json
   git add static.json
   git commit -m "Add static.json for Heroku"
   ```

7. **Deploy**
   ```bash
   git subtree push --prefix backend heroku main
   ```

### Option 2: DigitalOcean App Platform

1. **Create DigitalOcean Account**
   - Visit [digitalocean.com](https://digitalocean.com)
   - Create an account

2. **Create New App**
   - Click "Create" > "Apps"
   - Connect your GitHub repository
   - Configure:
     - Build command: `cd backend && npm install`
     - Run command: `cd backend && npm start`
     - HTTP Port: 3000

3. **Set Environment Variables**
   - In App Settings > Environment
   - Add all variables from `.env.example`

4. **Deploy**
   - Click "Deploy" and wait for completion

### Option 3: AWS Elastic Beanstalk

1. **Install AWS CLI and EB CLI**
   ```bash
   pip install awsebcli --upgrade --user
   ```

2. **Initialize EB Application**
   ```bash
   cd eldercare-app
   eb init eldercare-app
   ```

3. **Create Environment**
   ```bash
   eb create production
   ```

4. **Deploy**
   ```bash
   eb deploy
   ```

---

## ⚙️ Environment Configuration

### Production Environment Variables

Create environment variables for your chosen platform:

```env
# Required
NODE_ENV=production
PORT=3000
DEFAULT_PRIMARY_CONTACT=+917006273804
DEFAULT_EMERGENCY_NUMBER=911

# SMS Integration (Optional but Recommended)
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE_NUMBER=your_twilio_number

# Email Notifications (Optional)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password

# Security
JWT_SECRET=your_random_jwt_secret_here
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

### Security Best Practices

1. **Use Strong Secrets**
   ```bash
   # Generate strong secrets
   openssl rand -base64 32
   ```

2. **Enable HTTPS**
   - All platforms above provide free SSL certificates
   - Never deploy without HTTPS

3. **Regular Backups**
   - Configure automated backups
   - Test backup restoration regularly

---

## 📱 SMS Integration Setup

### Twilio Configuration (Recommended)

1. **Create Twilio Account**
   - Visit [twilio.com](https://twilio.com)
   - Sign up for a free trial

2. **Get Phone Number**
   - Console > Phone Numbers > Buy a Number
   - Choose a number in your target country

3. **Find Credentials**
   - Console > Project Info
   - Note Account SID and Auth Token

4. **Configure Environment**
   ```env
   TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   TWILIO_AUTH_TOKEN=your_auth_token_here
   TWILIO_PHONE_NUMBER=+1234567890
   ```

5. **Test SMS Functionality**
   ```bash
   curl -X POST https://your-app.com/api/emergency/test
   ```

### Alternative SMS Providers

- **AWS SNS**: More reliable, pay-per-use
- **MessageBird**: European-focused, competitive pricing
- **Plivo**: Developer-friendly API

---

## 🌐 Domain and SSL Setup

### Custom Domain Configuration

1. **Buy a Domain**
   - Recommended: Namecheap, GoDaddy, Cloudflare

2. **Configure DNS**
   ```
   # For most platforms
   A record: @ -> platform-ip-address
   CNAME record: www -> your-platform-url.com
   
   # For Cloudflare (recommended)
   A record: @ -> platform-ip-address
   CNAME record: www -> your-domain.com
   ```

3. **SSL Certificate**
   - Most platforms provide automatic SSL
   - Always use HTTPS in production

### CDN Configuration (Optional)

1. **Cloudflare Setup**
   - Sign up for Cloudflare
   - Add your domain
   - Change nameservers to Cloudflare

2. **Performance Settings**
   - Enable Brotli compression
   - Configure caching rules
   - Enable security features

---

## 🔍 Testing Your Deployment

### Health Check

1. **Test API Health**
   ```bash
   curl https://your-app.com/api/health
   ```

2. **Test Emergency System**
   - Open app in browser
   - Use "Test Emergency System" button
   - Verify alerts work

3. **Test Mobile Experience**
   - Test on actual mobile devices
   - Verify touch and audio work
   - Test offline functionality

### Monitoring

1. **Uptime Monitoring**
   - Use UptimeRobot (free)
   - Monitor `/api/health` endpoint

2. **Error Tracking**
   - Consider Sentry for error tracking
   - Monitor server logs regularly

---

## 📋 Deployment Checklist

### Pre-Deployment Checklist

- [ ] Environment variables configured
- [ ] SMS integration tested
- [ ] Emergency contact number verified
- [ ] SSL certificate installed
- [ ] Domain pointed correctly
- [ ] Rate limiting configured
- [ ] Backups enabled
- [ ] Monitoring set up

### Post-Deployment Checklist

- [ ] Health check passing
- [ ] Emergency system tested
- [ ] Mobile devices tested
- [ ] Browser compatibility checked
- [ ] Performance optimized
- [ ] Security scan completed

---

## 🆘 Emergency Response Protocol

For production deployments, establish these procedures:

1. **Emergency Contact Verification**
   - Test all emergency contacts
   - Verify SMS delivery
   - Confirm phone numbers work

2. **Monitoring Setup**
   - 24/7 uptime monitoring
   - Error alerting
   - Performance tracking

3. **Incident Response**
   - Emergency contact procedures
   - Backup restoration process
   - Communication plan

---

## 🤝 Support and Maintenance

### Regular Maintenance

1. **Weekly**
   - Check error logs
   - Verify SMS functionality
   - Monitor uptime

2. **Monthly**
   - Update dependencies
   - Test backup restoration
   - Review security settings

3. **Quarterly**
   - Full security audit
   - Performance optimization
   - Feature updates

### Getting Help

- **Documentation**: Check this guide first
- **Issues**: Create GitHub issue for bugs
- **Emergency**: Contact platform support directly

---

**🎉 Your ElderCare application is now ready for production deployment!**

Remember to test thoroughly, especially the emergency features, before making it available to users.