#!/bin/bash

# ElderCare App Setup Script
# This script helps you set up the ElderCare emergency and wellness app

echo "🚨 Welcome to ElderCare App Setup! 🚨"
echo "======================================"
echo "Setting up your emergency and wellness assistant for elderly users..."
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 14+ first."
    echo "Visit: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js found: $(node --version)"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

echo "✅ npm found: $(npm --version)"

# Install backend dependencies
echo ""
echo "📦 Installing backend dependencies..."
cd backend

if [ -f "package.json" ]; then
    npm install
    echo "✅ Backend dependencies installed successfully"
else
    echo "❌ package.json not found in backend directory"
    exit 1
fi

# Create environment file
if [ ! -f ".env" ]; then
    echo ""
    echo "⚙️ Creating environment configuration..."
    cp .env.example .env
    echo "✅ .env file created from template"
    echo "📝 Please edit backend/.env with your configuration"
else
    echo "✅ .env file already exists"
fi

cd ..

# Test backend server
echo ""
echo "🧪 Testing backend server..."
cd backend
timeout 10s npm start &
SERVER_PID=$!
sleep 3

if curl -f http://localhost:3000/api/health &> /dev/null; then
    echo "✅ Backend server is working correctly"
else
    echo "⚠️  Backend server test failed (may need configuration)"
fi

kill $SERVER_PID 2>/dev/null
cd ..

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "📱 Quick Start Instructions:"
echo "1. Start backend server: cd backend && npm start"
echo "2. Open browser to: http://localhost:3000"
echo "3. Add your emergency contacts"
echo "4. Configure medicine reminders"
echo "5. Test the SOS emergency button"
echo ""
echo "🚨 Important Emergency Contact Configured:"
echo "   Primary Contact: +91 7006273804"
echo "   Emergency Services: 911 (configurable in .env)"
echo ""
echo "📚 For deployment options, see DEPLOYMENT.md"
echo "🐛 For issues, check README.md"
echo ""
echo "⚠️  Remember to test the emergency features before real use!"
echo ""
echo "❤️ Made with care for elderly users"