// ElderCare - Frontend JavaScript

// Global variables
let emergencyContacts = [];
let medicineReminders = [];
let currentAlarm = null;

// Backend API URL (adjust based on deployment)
const API_URL = window.location.hostname === 'localhost' 
    ? 'http://localhost:3000/api' 
    : 'https://your-backend-url.com/api';

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    loadEmergencyContacts();
    loadMedicineReminders();
    checkScheduledReminders();
    requestNotificationPermission();
    
    // Check for reminders every minute
    setInterval(checkScheduledReminders, 60000);
}

// Request notification permission
function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
}

// Emergency Functions
function triggerSOS() {
    const confirmed = confirm('🚨 EMERGENCY SOS ACTIVATED!\n\nThis will alert all your emergency contacts and emergency services.\n\nContinue?');
    
    if (confirmed) {
        activateSOSAlarm();
        sendSOSSignal();
        showEmergencyMessage();
    }
}

function activateSOSAlarm() {
    const alarmSound = document.getElementById('alarm-sound');
    alarmSound.loop = true;
    alarmSound.play().catch(e => console.log('Audio play failed:', e));
    
    // Visual alert
    document.body.style.animation = 'pulse 0.5s infinite';
    
    // Vibrate if supported
    if ('vibrate' in navigator) {
        navigator.vibrate([200, 100, 200, 100, 200]);
    }
}

function stopSOSAlarm() {
    const alarmSound = document.getElementById('alarm-sound');
    alarmSound.pause();
    alarmSound.currentTime = 0;
    document.body.style.animation = '';
}

function sendSOSSignal() {
    // Send to backend
    fetch(`${API_URL}/emergency/sos`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            timestamp: new Date().toISOString(),
            location: getCurrentLocation()
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log('SOS signal sent:', data);
    })
    .catch(error => {
        console.error('Error sending SOS:', error);
        // Fallback: direct actions
        callAllContacts();
    });
}

function callEmergencyContact(contactId) {
    const contact = emergencyContacts.find(c => c.id === contactId);
    if (contact) {
        makePhoneCall(contact.phone);
        logEmergencyCall(contact);
    }
}

function callEmergencyServices() {
    // Call emergency services (customize based on country)
    makePhoneCall('911'); // Change to local emergency number
    logEmergencyCall({ name: 'Emergency Services', phone: '911' });
}

function makePhoneCall(phoneNumber) {
    window.location.href = `tel:${phoneNumber}`;
}

function logEmergencyCall(contact) {
    fetch(`${API_URL}/emergency/log-call`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            contact: contact,
            timestamp: new Date().toISOString()
        })
    });
}

function callAllContacts() {
    emergencyContacts.forEach((contact, index) => {
        setTimeout(() => {
            makePhoneCall(contact.phone);
        }, index * 2000); // Stagger calls by 2 seconds
    });
}

// Contact Management
function loadEmergencyContacts() {
    fetch(`${API_URL}/contacts`)
        .then(response => response.json())
        .then(data => {
            emergencyContacts = data;
            displayContacts();
        })
        .catch(error => {
            console.error('Error loading contacts:', error);
            // Load from localStorage as fallback
            loadContactsFromStorage();
        });
}

function loadContactsFromStorage() {
    const stored = localStorage.getItem('emergencyContacts');
    if (stored) {
        emergencyContacts = JSON.parse(stored);
        displayContacts();
    }
}

function displayContacts() {
    const contactsList = document.getElementById('contacts-list');
    
    if (emergencyContacts.length === 0) {
        contactsList.innerHTML = '<p style="text-align: center; color: #7f8c8d;">No emergency contacts added yet.</p>';
        return;
    }
    
    contactsList.innerHTML = emergencyContacts.map(contact => `
        <div class="contact-item">
            <div class="contact-info">
                <div class="contact-name">${contact.name}</div>
                <div class="contact-phone">${contact.phone}</div>
                ${contact.relation ? `<div style="color: #7f8c8d;">${contact.relation}</div>` : ''}
            </div>
            <div class="contact-actions">
                <button class="btn btn-small btn-emergency" onclick="callEmergencyContact('${contact.id}')">
                    📞 Call
                </button>
                <button class="btn btn-small btn-secondary" onclick="deleteContact('${contact.id}')">
                    🗑️
                </button>
            </div>
        </div>
    `).join('');
}

function showAddContact() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h3>Add Emergency Contact</h3>
        <form id="add-contact-form">
            <div class="form-group">
                <label for="contact-name">Name *</label>
                <input type="text" id="contact-name" required placeholder="Enter contact name">
            </div>
            <div class="form-group">
                <label for="contact-phone">Phone Number *</label>
                <input type="tel" id="contact-phone" required placeholder="+91 7006273804">
            </div>
            <div class="form-group">
                <label for="contact-relation">Relationship</label>
                <input type="text" id="contact-relation" placeholder="Son, Daughter, Friend, etc.">
            </div>
            <div class="form-group">
                <label>
                    <input type="checkbox" id="contact-primary"> Primary Emergency Contact
                </label>
            </div>
            <button type="submit" class="btn btn-emergency">Add Contact</button>
        </form>
    `;
    
    showModal();
    
    document.getElementById('add-contact-form').addEventListener('submit', addContact);
}

function addContact(e) {
    e.preventDefault();
    
    const contact = {
        id: Date.now().toString(),
        name: document.getElementById('contact-name').value,
        phone: document.getElementById('contact-phone').value,
        relation: document.getElementById('contact-relation').value,
        isPrimary: document.getElementById('contact-primary').checked,
        createdAt: new Date().toISOString()
    };
    
    // Save to backend
    fetch(`${API_URL}/contacts`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(contact)
    })
    .then(response => response.json())
    .then(data => {
        emergencyContacts.push(data);
        displayContacts();
        closeModal();
        showAlert('Contact added successfully!', 'success');
    })
    .catch(error => {
        console.error('Error adding contact:', error);
        // Fallback to localStorage
        emergencyContacts.push(contact);
        localStorage.setItem('emergencyContacts', JSON.stringify(emergencyContacts));
        displayContacts();
        closeModal();
        showAlert('Contact added locally!', 'warning');
    });
}

function deleteContact(contactId) {
    const confirmed = confirm('Are you sure you want to delete this emergency contact?');
    
    if (confirmed) {
        fetch(`${API_URL}/contacts/${contactId}`, {
            method: 'DELETE'
        })
        .then(() => {
            emergencyContacts = emergencyContacts.filter(c => c.id !== contactId);
            displayContacts();
            showAlert('Contact deleted successfully!', 'success');
        })
        .catch(error => {
            console.error('Error deleting contact:', error);
            // Fallback to localStorage
            emergencyContacts = emergencyContacts.filter(c => c.id !== contactId);
            localStorage.setItem('emergencyContacts', JSON.stringify(emergencyContacts));
            displayContacts();
            showAlert('Contact deleted locally!', 'warning');
        });
    }
}

// Medicine Reminders
function showMedicineReminders() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h3>💊 Medicine Reminders</h3>
        <div id="reminders-list">
            ${displayReminders()}
        </div>
        <button class="btn btn-wellness" onclick="showAddReminder()">Add New Reminder</button>
        <button class="btn btn-secondary" onclick="closeModal()">Close</button>
    `;
    showModal();
}

function displayReminders() {
    if (medicineReminders.length === 0) {
        return '<p style="text-align: center; color: #7f8c8d;">No medicine reminders set yet.</p>';
    }
    
    return medicineReminders.map(reminder => `
        <div class="reminder-item">
            <div class="reminder-time">⏰ ${reminder.time}</div>
            <div class="reminder-medicine">${reminder.medicine}</div>
            <div class="reminder-dosage">Dosage: ${reminder.dosage}</div>
            <div style="margin-top: 10px;">
                <button class="btn btn-small btn-secondary" onclick="deleteReminder('${reminder.id}')">Delete</button>
                <button class="btn btn-small btn-wellness" onclick="markMedicineTaken('${reminder.id}')">Taken ✓</button>
            </div>
        </div>
    `).join('');
}

function showAddReminder() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h3>Add Medicine Reminder</h3>
        <form id="add-reminder-form">
            <div class="form-group">
                <label for="medicine-name">Medicine Name *</label>
                <input type="text" id="medicine-name" required placeholder="Enter medicine name">
            </div>
            <div class="form-group">
                <label for="medicine-dosage">Dosage *</label>
                <input type="text" id="medicine-dosage" required placeholder="e.g., 1 tablet, 5ml">
            </div>
            <div class="form-group">
                <label for="medicine-time">Time *</label>
                <input type="time" id="medicine-time" required>
            </div>
            <div class="form-group">
                <label for="medicine-frequency">Frequency</label>
                <select id="medicine-frequency">
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                </select>
            </div>
            <button type="submit" class="btn btn-wellness">Add Reminder</button>
        </form>
    `;
    
    showModal();
    document.getElementById('add-reminder-form').addEventListener('submit', addReminder);
}

function addReminder(e) {
    e.preventDefault();
    
    const reminder = {
        id: Date.now().toString(),
        medicine: document.getElementById('medicine-name').value,
        dosage: document.getElementById('medicine-dosage').value,
        time: document.getElementById('medicine-time').value,
        frequency: document.getElementById('medicine-frequency').value,
        createdAt: new Date().toISOString()
    };
    
    fetch(`${API_URL}/reminders`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(reminder)
    })
    .then(response => response.json())
    .then(data => {
        medicineReminders.push(data);
        showMedicineReminders();
        showAlert('Medicine reminder added!', 'success');
    })
    .catch(error => {
        console.error('Error adding reminder:', error);
        // Fallback to localStorage
        medicineReminders.push(reminder);
        localStorage.setItem('medicineReminders', JSON.stringify(medicineReminders));
        showMedicineReminders();
        showAlert('Reminder added locally!', 'warning');
    });
}

function deleteReminder(reminderId) {
    fetch(`${API_URL}/reminders/${reminderId}`, {
        method: 'DELETE'
    })
    .then(() => {
        medicineReminders = medicineReminders.filter(r => r.id !== reminderId);
        showMedicineReminders();
        showAlert('Reminder deleted!', 'success');
    })
    .catch(error => {
        console.error('Error deleting reminder:', error);
        medicineReminders = medicineReminders.filter(r => r.id !== reminderId);
        localStorage.setItem('medicineReminders', JSON.stringify(medicineReminders));
        showMedicineReminders();
    });
}

function checkScheduledReminders() {
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
    
    medicineReminders.forEach(reminder => {
        if (reminder.time === currentTime) {
            triggerMedicineAlarm(reminder);
        }
    });
}

function triggerMedicineAlarm(reminder) {
    // Show notification
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('💊 Medicine Reminder', {
            body: `Time to take ${reminder.medicine} - ${reminder.dosage}`,
            icon: '💊',
            requireInteraction: true
        });
    }
    
    // Play alarm sound
    const alarmSound = document.getElementById('alarm-sound');
    alarmSound.play().catch(e => console.log('Audio play failed:', e));
    
    // Vibrate
    if ('vibrate' in navigator) {
        navigator.vibrate([500, 200, 500]);
    }
    
    // Show modal
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <div class="alert alert-warning" style="text-align: center;">
            <h2>💊 Medicine Time!</h2>
            <p style="font-size: 1.3em; margin: 20px 0;">${reminder.medicine}</p>
            <p style="font-size: 1.1em;">Dosage: ${reminder.dosage}</p>
            <button class="btn btn-wellness" onclick="markMedicineTaken('${reminder.id}'); closeModal(); stopAlarmSound();">Taken ✓</button>
            <button class="btn btn-secondary" onclick="snoozeReminder('${reminder.id}');">Snooze 5 min</button>
        </div>
    `;
    showModal();
}

function markMedicineTaken(reminderId) {
    fetch(`${API_URL}/reminders/${reminderId}/taken`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        console.log('Medicine marked as taken:', data);
        showAlert('Medicine marked as taken. Good job!', 'success');
    })
    .catch(error => {
        console.error('Error marking medicine as taken:', error);
    });
}

function snoozeReminder(reminderId) {
    closeModal();
    setTimeout(() => {
        const reminder = medicineReminders.find(r => r.id === reminderId);
        if (reminder) {
            triggerMedicineAlarm(reminder);
        }
    }, 300000); // 5 minutes
}

function stopAlarmSound() {
    const alarmSound = document.getElementById('alarm-sound');
    alarmSound.pause();
    alarmSound.currentTime = 0;
}

// Wellness Functions
function showDailySchedule() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h3>📅 Daily Wellness Schedule</h3>
        <div class="schedule-container">
            <div class="schedule-item">
                <strong>🌅 Morning (6:00 AM - 9:00 AM)</strong>
                <ul>
                    <li>Wake up and stretch</li>
                    <li>Take morning medicines</li>
                    <li>Healthy breakfast</li>
                    <li>Light exercise or walk</li>
                </ul>
            </div>
            <div class="schedule-item">
                <strong>☀️ Afternoon (12:00 PM - 2:00 PM)</strong>
                <ul>
                    <li>Lunch time</li>
                    <li>Afternoon medicines</li>
                    <li>Rest period</li>
                </ul>
            </div>
            <div class="schedule-item">
                <strong>🌆 Evening (5:00 PM - 8:00 PM)</strong>
                <ul>
                    <li>Light activity or hobby</li>
                    <li>Dinner</li>
                    <li>Evening medicines</li>
                </ul>
            </div>
            <div class="schedule-item">
                <strong>🌙 Night (9:00 PM - 10:00 PM)</strong>
                <ul>
                    <li>Prepare for sleep</li>
                    <li>Night medicines if needed</li>
                    <li>Relaxation time</li>
                </ul>
            </div>
        </div>
        <button class="btn btn-secondary" onclick="closeModal()">Close</button>
    `;
    showModal();
}

function showHealthTips() {
    const tips = [
        "Stay hydrated - drink at least 8 glasses of water daily",
        "Take medications exactly as prescribed by your doctor",
        "Exercise regularly - even 15 minutes of walking helps",
        "Maintain a regular sleep schedule",
        "Eat a balanced diet with fruits and vegetables",
        "Keep emergency contacts updated and accessible",
        "Attend regular medical check-ups",
        "Practice good hygiene to prevent infections",
        "Stay socially connected with family and friends",
        "Keep your mind active with puzzles or reading"
    ];
    
    const randomTip = tips[Math.floor(Math.random() * tips.length)];
    
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h3>❤️ Health Tip of the Day</h3>
        <div class="alert alert-success" style="font-size: 1.2em; line-height: 1.6;">
            ${randomTip}
        </div>
        <button class="btn btn-wellness" onclick="showHealthTips()">Another Tip 💡</button>
        <button class="btn btn-secondary" onclick="closeModal()">Close</button>
    `;
    showModal();
}

// Settings Functions
function showSettings() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h3>⚙️ App Settings</h3>
        <form id="settings-form">
            <div class="form-group">
                <label for="user-name">Your Name</label>
                <input type="text" id="user-name" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="user-phone">Your Phone Number</label>
                <input type="tel" id="user-phone" placeholder="+91 7006273804">
            </div>
            <div class="form-group">
                <label>
                    <input type="checkbox" id="notifications-enabled" checked> Enable Notifications
                </label>
            </div>
            <div class="form-group">
                <label>
                    <input type="checkbox" id="alarm-enabled" checked> Enable Alarm Sounds
                </label>
            </div>
            <div class="form-group">
                <label for="emergency-number">Emergency Services Number</label>
                <input type="tel" id="emergency-number" value="911">
            </div>
            <button type="submit" class="btn btn-settings">Save Settings</button>
        </form>
        <hr style="margin: 20px 0;">
        <button class="btn btn-secondary" onclick="exportData()">📥 Export Data</button>
        <button class="btn btn-secondary" onclick="importData()">📤 Import Data</button>
        <button class="btn btn-emergency" onclick="resetApp()">🔄 Reset App</button>
    `;
    
    showModal();
    loadUserSettings();
    document.getElementById('settings-form').addEventListener('submit', saveUserSettings);
}

function loadUserSettings() {
    const settings = JSON.parse(localStorage.getItem('userSettings') || '{}');
    
    if (settings.name) document.getElementById('user-name').value = settings.name;
    if (settings.phone) document.getElementById('user-phone').value = settings.phone;
    if (settings.emergencyNumber) document.getElementById('emergency-number').value = settings.emergencyNumber;
    
    document.getElementById('notifications-enabled').checked = settings.notifications !== false;
    document.getElementById('alarm-enabled').checked = settings.alarms !== false;
}

function saveUserSettings(e) {
    e.preventDefault();
    
    const settings = {
        name: document.getElementById('user-name').value,
        phone: document.getElementById('user-phone').value,
        emergencyNumber: document.getElementById('emergency-number').value,
        notifications: document.getElementById('notifications-enabled').checked,
        alarms: document.getElementById('alarm-enabled').checked,
        updatedAt: new Date().toISOString()
    };
    
    localStorage.setItem('userSettings', JSON.stringify(settings));
    
    fetch(`${API_URL}/user/settings`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(settings)
    })
    .then(response => response.json())
    .then(data => {
        showAlert('Settings saved successfully!', 'success');
    })
    .catch(error => {
        console.error('Error saving settings:', error);
        showAlert('Settings saved locally!', 'warning');
    });
}

function testEmergencySystem() {
    const confirmed = confirm('This will test the emergency system with a silent alert. Continue?');
    
    if (confirmed) {
        showAlert('Emergency system test initiated. Check your alerts!', 'warning');
        
        // Test notification
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('🚨 Emergency System Test', {
                body: 'This is a test of the emergency alert system. All systems are working correctly.',
                icon: '🚨'
            });
        }
        
        // Log test to backend
        fetch(`${API_URL}/emergency/test`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                timestamp: new Date().toISOString(),
                type: 'system_test'
            })
        });
    }
}

function exportData() {
    const data = {
        contacts: emergencyContacts,
        reminders: medicineReminders,
        settings: JSON.parse(localStorage.getItem('userSettings') || '{}'),
        exportedAt: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `eldercare-backup-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    showAlert('Data exported successfully!', 'success');
}

function importData() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = e => {
        const file = e.target.files[0];
        const reader = new FileReader();
        
        reader.onload = event => {
            try {
                const data = JSON.parse(event.target.result);
                
                // Import contacts
                if (data.contacts) {
                    emergencyContacts = data.contacts;
                    displayContacts();
                }
                
                // Import reminders
                if (data.reminders) {
                    medicineReminders = data.reminders;
                }
                
                // Import settings
                if (data.settings) {
                    localStorage.setItem('userSettings', JSON.stringify(data.settings));
                }
                
                showAlert('Data imported successfully!', 'success');
                closeModal();
                
            } catch (error) {
                showAlert('Error importing data. Please check the file format.', 'danger');
            }
        };
        
        reader.readAsText(file);
    };
    
    input.click();
}

function resetApp() {
    const confirmed = confirm('⚠️ WARNING: This will reset all app data including contacts, reminders, and settings. This action cannot be undone. Continue?');
    
    if (confirmed) {
        const doubleConfirmed = confirm('Are you absolutely sure? All data will be permanently deleted.');
        
        if (doubleConfirmed) {
            localStorage.clear();
            emergencyContacts = [];
            medicineReminders = [];
            
            fetch(`${API_URL}/reset`, {
                method: 'POST'
            }).catch(error => {
                console.log('Backend reset failed, but local data cleared');
            });
            
            showAlert('App reset successfully. All data has been cleared.', 'success');
            closeModal();
            setTimeout(() => {
                location.reload();
            }, 2000);
        }
    }
}

// Utility Functions
function getCurrentLocation() {
    return new Promise((resolve, reject) => {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                position => {
                    resolve({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    });
                },
                error => {
                    reject(error);
                }
            );
        } else {
            reject('Geolocation not available');
        }
    });
}

function showEmergencyMessage() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <div class="alert alert-danger" style="text-align: center;">
            <h2>🚨 EMERGENCY ALERT ACTIVATED 🚨</h2>
            <p style="font-size: 1.2em; margin: 20px 0;">
                Emergency contacts have been notified.<br>
                Help is on the way!<br>
                Stay calm and try to remain safe.
            </p>
            <button class="btn btn-emergency" onclick="stopSOSAlarm(); closeModal();">Stop Alert</button>
        </div>
    `;
    showModal();
}

function showModal() {
    document.getElementById('modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
    stopAlarmSound();
}

function showAlert(message, type = 'info') {
    // Create alert element
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.innerHTML = message;
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        max-width: 400px;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    
    document.body.appendChild(alert);
    
    // Remove after 5 seconds
    setTimeout(() => {
        if (alert.parentNode) {
            alert.parentNode.removeChild(alert);
        }
    }, 5000);
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('modal');
    if (event.target === modal) {
        closeModal();
    }
}

// Keyboard shortcuts for emergency
document.addEventListener('keydown', function(event) {
    // SOS with Ctrl/Cmd + Shift + S
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'S') {
        event.preventDefault();
        triggerSOS();
    }
    
    // Close modal with Escape
    if (event.key === 'Escape') {
        closeModal();
    }
});

// Service Worker for offline functionality (optional)
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(registration => {
            console.log('ServiceWorker registration successful');
        })
        .catch(error => {
            console.log('ServiceWorker registration failed');
        });
}