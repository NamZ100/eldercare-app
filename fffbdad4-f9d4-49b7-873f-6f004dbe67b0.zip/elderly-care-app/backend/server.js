const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const rateLimit = require('express-rate-limit');
const cron = require('node-cron');
const path = require('path');

// Load environment variables
dotenv.config();

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting for security
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // limit each IP to 100 requests per windowMs
});
app.use('/api/', limiter);

// Emergency rate limiting (stricter)
const emergencyLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 5, // limit each IP to 5 emergency requests per minute
    message: 'Too many emergency requests. Please wait before trying again.'
});

// In-memory storage (replace with database in production)
let emergencyContacts = [];
let medicineReminders = [];
let users = {};
let emergencyLogs = [];
let reminderLogs = [];

// Default emergency contact (from user request)
const DEFAULT_EMERGENCY_CONTACT = {
    id: 'default-primary',
    name: 'Primary Emergency Contact',
    phone: '+917006273804',
    relation: 'Primary',
    isPrimary: true,
    createdAt: new Date().toISOString()
};

// Initialize with default contact
emergencyContacts.push(DEFAULT_EMERGENCY_CONTACT);

// Serve static files for frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// API Routes

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        features: {
            emergency: true,
            reminders: true,
            contacts: true,
            sms: true,
            notifications: true
        }
    });
});

// Emergency endpoints
app.post('/api/emergency/sos', emergencyLimiter, async (req, res) => {
    try {
        const { location, timestamp } = req.body;
        
        const sosAlert = {
            id: Date.now().toString(),
            type: 'SOS',
            timestamp: timestamp || new Date().toISOString(),
            location: location || null,
            contactsNotified: emergencyContacts.length,
            status: 'activated'
        };
        
        emergencyLogs.push(sosAlert);
        
        // Send alerts to all contacts
        const alertsSent = await sendEmergencyAlerts(sosAlert);
        
        res.json({
            success: true,
            message: 'SOS alert activated successfully',
            alertId: sosAlert.id,
            contactsNotified: alertsSent,
            emergencyNumber: '911'
        });
        
    } catch (error) {
        console.error('SOS activation error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to activate SOS alert',
            error: error.message
        });
    }
});

app.post('/api/emergency/log-call', (req, res) => {
    try {
        const { contact, timestamp } = req.body;
        
        const callLog = {
            id: Date.now().toString(),
            contact: contact,
            timestamp: timestamp || new Date().toISOString(),
            type: 'emergency_call'
        };
        
        emergencyLogs.push(callLog);
        
        res.json({
            success: true,
            message: 'Emergency call logged successfully',
            logId: callLog.id
        });
        
    } catch (error) {
        console.error('Call logging error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to log emergency call'
        });
    }
});

app.post('/api/emergency/test', (req, res) => {
    try {
        const testLog = {
            id: Date.now().toString(),
            type: 'system_test',
            timestamp: new Date().toISOString(),
            status: 'completed'
        };
        
        emergencyLogs.push(testLog);
        
        res.json({
            success: true,
            message: 'Emergency system test completed successfully',
            testId: testLog.id
        });
        
    } catch (error) {
        console.error('System test error:', error);
        res.status(500).json({
            success: false,
            message: 'System test failed'
        });
    }
});

// Contact management endpoints
app.get('/api/contacts', (req, res) => {
    try {
        res.json({
            success: true,
            contacts: emergencyContacts,
            count: emergencyContacts.length
        });
    } catch (error) {
        console.error('Error fetching contacts:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch contacts'
        });
    }
});

app.post('/api/contacts', (req, res) => {
    try {
        const contact = {
            ...req.body,
            id: Date.now().toString(),
            createdAt: new Date().toISOString()
        };
        
        // Validate required fields
        if (!contact.name || !contact.phone) {
            return res.status(400).json({
                success: false,
                message: 'Name and phone number are required'
            });
        }
        
        // If this is set as primary, unset other primary contacts
        if (contact.isPrimary) {
            emergencyContacts = emergencyContacts.map(c => ({
                ...c,
                isPrimary: false
            }));
        }
        
        emergencyContacts.push(contact);
        
        res.status(201).json({
            success: true,
            message: 'Contact added successfully',
            contact: contact
        });
        
    } catch (error) {
        console.error('Error adding contact:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to add contact'
        });
    }
});

app.put('/api/contacts/:id', (req, res) => {
    try {
        const { id } = req.params;
        const updatedContact = req.body;
        
        const contactIndex = emergencyContacts.findIndex(c => c.id === id);
        
        if (contactIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Contact not found'
            });
        }
        
        // If this is set as primary, unset other primary contacts
        if (updatedContact.isPrimary) {
            emergencyContacts = emergencyContacts.map(c => ({
                ...c,
                isPrimary: false
            }));
        }
        
        emergencyContacts[contactIndex] = {
            ...emergencyContacts[contactIndex],
            ...updatedContact,
            updatedAt: new Date().toISOString()
        };
        
        res.json({
            success: true,
            message: 'Contact updated successfully',
            contact: emergencyContacts[contactIndex]
        });
        
    } catch (error) {
        console.error('Error updating contact:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update contact'
        });
    }
});

app.delete('/api/contacts/:id', (req, res) => {
    try {
        const { id } = req.params;
        
        const contactIndex = emergencyContacts.findIndex(c => c.id === id);
        
        if (contactIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Contact not found'
            });
        }
        
        // Don't allow deletion of the default contact
        if (id === DEFAULT_EMERGENCY_CONTACT.id) {
            return res.status(400).json({
                success: false,
                message: 'Cannot delete default emergency contact'
            });
        }
        
        const deletedContact = emergencyContacts.splice(contactIndex, 1)[0];
        
        res.json({
            success: true,
            message: 'Contact deleted successfully',
            contact: deletedContact
        });
        
    } catch (error) {
        console.error('Error deleting contact:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete contact'
        });
    }
});

// Medicine reminder endpoints
app.get('/api/reminders', (req, res) => {
    try {
        res.json({
            success: true,
            reminders: medicineReminders,
            count: medicineReminders.length
        });
    } catch (error) {
        console.error('Error fetching reminders:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch reminders'
        });
    }
});

app.post('/api/reminders', (req, res) => {
    try {
        const reminder = {
            ...req.body,
            id: Date.now().toString(),
            createdAt: new Date().toISOString(),
            active: true
        };
        
        // Validate required fields
        if (!reminder.medicine || !reminder.dosage || !reminder.time) {
            return res.status(400).json({
                success: false,
                message: 'Medicine name, dosage, and time are required'
            });
        }
        
        medicineReminders.push(reminder);
        
        res.status(201).json({
            success: true,
            message: 'Reminder added successfully',
            reminder: reminder
        });
        
    } catch (error) {
        console.error('Error adding reminder:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to add reminder'
        });
    }
});

app.put('/api/reminders/:id', (req, res) => {
    try {
        const { id } = req.params;
        const updatedReminder = req.body;
        
        const reminderIndex = medicineReminders.findIndex(r => r.id === id);
        
        if (reminderIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Reminder not found'
            });
        }
        
        medicineReminders[reminderIndex] = {
            ...medicineReminders[reminderIndex],
            ...updatedReminder,
            updatedAt: new Date().toISOString()
        };
        
        res.json({
            success: true,
            message: 'Reminder updated successfully',
            reminder: medicineReminders[reminderIndex]
        });
        
    } catch (error) {
        console.error('Error updating reminder:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update reminder'
        });
    }
});

app.delete('/api/reminders/:id', (req, res) => {
    try {
        const { id } = req.params;
        
        const reminderIndex = medicineReminders.findIndex(r => r.id === id);
        
        if (reminderIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Reminder not found'
            });
        }
        
        const deletedReminder = medicineReminders.splice(reminderIndex, 1)[0];
        
        res.json({
            success: true,
            message: 'Reminder deleted successfully',
            reminder: deletedReminder
        });
        
    } catch (error) {
        console.error('Error deleting reminder:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete reminder'
        });
    }
});

app.post('/api/reminders/:id/taken', (req, res) => {
    try {
        const { id } = req.params;
        
        const reminderIndex = medicineReminders.findIndex(r => r.id === id);
        
        if (reminderIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Reminder not found'
            });
        }
        
        const logEntry = {
            id: Date.now().toString(),
            reminderId: id,
            medicine: medicineReminders[reminderIndex].medicine,
            takenAt: new Date().toISOString(),
            status: 'taken'
        };
        
        reminderLogs.push(logEntry);
        
        res.json({
            success: true,
            message: 'Medicine marked as taken',
            log: logEntry
        });
        
    } catch (error) {
        console.error('Error marking medicine as taken:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to mark medicine as taken'
        });
    }
});

// User settings endpoints
app.post('/api/user/settings', (req, res) => {
    try {
        const settings = {
            ...req.body,
            updatedAt: new Date().toISOString()
        };
        
        // In a real app, this would be tied to a user ID
        const userId = 'default-user';
        users[userId] = { ...users[userId], settings };
        
        res.json({
            success: true,
            message: 'Settings saved successfully',
            settings: settings
        });
        
    } catch (error) {
        console.error('Error saving settings:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to save settings'
        });
    }
});

app.get('/api/user/settings', (req, res) => {
    try {
        const userId = 'default-user';
        const settings = users[userId]?.settings || {};
        
        res.json({
            success: true,
            settings: settings
        });
        
    } catch (error) {
        console.error('Error fetching settings:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch settings'
        });
    }
});

// Data export/import endpoints
app.get('/api/export', (req, res) => {
    try {
        const exportData = {
            contacts: emergencyContacts,
            reminders: medicineReminders,
            reminderLogs: reminderLogs,
            emergencyLogs: emergencyLogs,
            exportedAt: new Date().toISOString(),
            version: '1.0.0'
        };
        
        res.json({
            success: true,
            data: exportData
        });
        
    } catch (error) {
        console.error('Error exporting data:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to export data'
        });
    }
});

app.post('/api/import', (req, res) => {
    try {
        const importData = req.body;
        
        // Validate import data structure
        if (!importData.contacts || !importData.reminders) {
            return res.status(400).json({
                success: false,
                message: 'Invalid import data format'
            });
        }
        
        // Merge with existing data (or replace, based on preference)
        emergencyContacts = [...emergencyContacts, ...importData.contacts];
        medicineReminders = [...medicineReminders, ...importData.reminders];
        
        if (importData.reminderLogs) {
            reminderLogs = [...reminderLogs, ...importData.reminderLogs];
        }
        
        if (importData.emergencyLogs) {
            emergencyLogs = [...emergencyLogs, ...importData.emergencyLogs];
        }
        
        res.json({
            success: true,
            message: 'Data imported successfully',
            imported: {
                contacts: importData.contacts.length,
                reminders: importData.reminders.length,
                reminderLogs: importData.reminderLogs?.length || 0,
                emergencyLogs: importData.emergencyLogs?.length || 0
            }
        });
        
    } catch (error) {
        console.error('Error importing data:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to import data'
        });
    }
});

app.post('/api/reset', (req, res) => {
    try {
        // Reset all data except default contact
        emergencyContacts = [DEFAULT_EMERGENCY_CONTACT];
        medicineReminders = [];
        reminderLogs = [];
        emergencyLogs = [];
        users = {};
        
        res.json({
            success: true,
            message: 'All data has been reset successfully'
        });
        
    } catch (error) {
        console.error('Error resetting data:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to reset data'
        });
    }
});

// Utility function to send emergency alerts
async function sendEmergencyAlerts(sosAlert) {
    let alertsSent = 0;
    
    for (const contact of emergencyContacts) {
        try {
            // Send SMS alert (using Twilio or similar service)
            await sendSMSAlert(contact, sosAlert);
            alertsSent++;
            
            // Wait between sends to avoid rate limiting
            await new Promise(resolve => setTimeout(resolve, 1000));
            
        } catch (error) {
            console.error(`Failed to send alert to ${contact.name}:`, error);
        }
    }
    
    return alertsSent;
}

// Send SMS alert (placeholder - integrate with SMS service)
async function sendSMSAlert(contact, sosAlert) {
    // This is a placeholder for SMS integration
    // In production, you would use Twilio, AWS SNS, or similar service
    
    console.log(`SMS Alert sent to ${contact.name} (${contact.phone}):`);
    console.log(`EMERGENCY: ${sosAlert.type} activated at ${sosAlert.timestamp}`);
    console.log(`Location: ${sosAlert.location ? JSON.stringify(sosAlert.location) : 'Unknown'}`);
    
    // Example Twilio integration (uncomment and configure):
    /*
    const twilio = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    
    await twilio.messages.create({
        body: `🚨 EMERGENCY ALERT 🚨\n\nSOS has been activated!\n\nTime: ${sosAlert.timestamp}\n${sosAlert.location ? `Location: ${sosAlert.location.latitude}, ${sosAlert.location.longitude}` : ''}\n\nPlease check on the person immediately.`,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: contact.phone
    });
    */
    
    return true;
}

// Scheduled task to check for reminders (every minute)
cron.schedule('* * * * *', () => {
    checkReminders();
});

// Check for due reminders
function checkReminders() {
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
    
    medicineReminders.forEach(reminder => {
        if (reminder.active && reminder.time === currentTime) {
            // In a real implementation, you would send push notifications or emails
            console.log(`Reminder due: ${reminder.medicine} at ${reminder.time}`);
            
            // Log the reminder trigger
            const logEntry = {
                id: Date.now().toString(),
                reminderId: reminder.id,
                medicine: reminder.medicine,
                triggeredAt: now.toISOString(),
                status: 'triggered'
            };
            
            reminderLogs.push(logEntry);
        }
    });
}

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
        success: false,
        message: 'Internal server error'
    });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'Endpoint not found'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 ElderCare Backend Server running on port ${PORT}`);
    console.log(`📱 API available at: http://localhost:${PORT}/api`);
    console.log(`🌐 Frontend available at: http://localhost:${PORT}`);
    console.log(`🔗 Default emergency contact: +917006273804`);
    console.log(`⏰ Reminder checking: Active`);
    console.log(`🚨 Emergency services: Ready`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    process.exit(0);
});

module.exports = app;