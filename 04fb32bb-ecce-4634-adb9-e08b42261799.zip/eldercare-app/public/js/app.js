// Eldercare Wellness App - Frontend JavaScript

// Configuration
const API_BASE_URL = 'http://localhost:3000/api';

// State Management
let currentSection = 'dashboard';
let contacts = [];
let medicines = [];
let wellnessRecords = [];

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

async function initializeApp() {
    // Load initial data
    await loadEmergencyContacts();
    await loadMedicines();
    await loadWellnessRecords();
    
    // Set up event listeners
    setupEventListeners();
    
    // Update dashboard
    updateDashboard();
    
    // Check for medicine reminders
    checkMedicineReminders();
    
    // Set up periodic reminder checks
    setInterval(checkMedicineReminders, 60000); // Check every minute
}

function setupEventListeners() {
    // Contact form submission
    document.getElementById('contact-form').addEventListener('submit', handleAddContact);
    
    // Medicine form submission
    document.getElementById('medicine-form').addEventListener('submit', handleAddMedicine);
    
    // Wellness form submission
    document.getElementById('wellness-form').addEventListener('submit', handleWellnessSubmit);
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
}

// Navigation Functions
function showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remove active class from all nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionName).classList.add('active');
    
    // Add active class to clicked nav button
    event.target.classList.add('active');
    
    currentSection = sectionName;
}

// Emergency Contact Functions
async function loadEmergencyContacts() {
    try {
        const response = await fetch(`${API_BASE_URL}/contacts`);
        contacts = await response.json();
        displayEmergencyContacts();
        updateDashboard();
    } catch (error) {
        console.error('Error loading contacts:', error);
        displayContactsError();
    }
}

function displayEmergencyContacts() {
    const container = document.getElementById('emergency-contacts-list');
    const previewContainer = document.getElementById('emergency-contacts-preview');
    
    if (contacts.length === 0) {
        container.innerHTML = '<p>No emergency contacts added yet.</p>';
        previewContainer.innerHTML = '<p>No emergency contacts added yet.</p>';
        return;
    }
    
    // Display in emergency section
    container.innerHTML = contacts.map(contact => `
        <div class="contact-item">
            <div class="contact-info">
                <div class="contact-name">
                    ${contact.name}
                    <span class="priority-badge ${getPriorityClass(contact.priority)}">
                        ${getPriorityLabel(contact.priority)}
                    </span>
                </div>
                <div class="contact-phone"><i class="fas fa-phone"></i> ${contact.phone}</div>
                <div class="contact-relation"><i class="fas fa-user"></i> ${contact.relation || 'No relation specified'}</div>
            </div>
            <div class="contact-actions">
                <button class="btn btn-primary" onclick="callContact('${contact.phone}')">
                    <i class="fas fa-phone"></i> Call
                </button>
                <button class="btn btn-danger" onclick="deleteContact('${contact.id}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    `).join('');
    
    // Display preview in dashboard
    const topContacts = contacts.slice(0, 3);
    previewContainer.innerHTML = topContacts.map(contact => `
        <div style="margin-bottom: 10px;">
            <strong>${contact.name}</strong> - ${contact.phone}
        </div>
    `).join('');
}

function getPriorityClass(priority) {
    switch(priority) {
        case '1': return '';
        case '2': return 'secondary';
        case '3': return 'tertiary';
        default: return '';
    }
}

function getPriorityLabel(priority) {
    switch(priority) {
        case '1': return 'Primary';
        case '2': return 'Secondary';
        case '3': return 'Tertiary';
        default: return 'Primary';
    }
}

function displayContactsError() {
    document.getElementById('emergency-contacts-list').innerHTML = 
        '<p style="color: red;">Error loading contacts. Please try again.</p>';
    document.getElementById('emergency-contacts-preview').innerHTML = 
        '<p style="color: red;">Error loading contacts.</p>';
}

// Modal Functions
function openAddContactModal() {
    document.getElementById('contact-modal').style.display = 'block';
}

function closeContactModal() {
    document.getElementById('contact-modal').style.display = 'none';
    document.getElementById('contact-form').reset();
}

async function handleAddContact(event) {
    event.preventDefault();
    
    const contact = {
        name: document.getElementById('contact-name').value,
        phone: document.getElementById('contact-phone').value,
        relation: document.getElementById('contact-relation').value,
        priority: document.getElementById('contact-priority').value
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/contacts`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(contact)
        });
        
        if (response.ok) {
            closeContactModal();
            await loadEmergencyContacts();
            showNotification('Emergency contact added successfully!', 'success');
        } else {
            throw new Error('Failed to add contact');
        }
    } catch (error) {
        console.error('Error adding contact:', error);
        showNotification('Failed to add emergency contact. Please try again.', 'error');
    }
}

// Medicine Functions
async function loadMedicines() {
    try {
        const response = await fetch(`${API_BASE_URL}/medicines`);
        medicines = await response.json();
        displayMedicines();
        updateDashboard();
    } catch (error) {
        console.error('Error loading medicines:', error);
        displayMedicinesError();
    }
}

function displayMedicines() {
    const todayContainer = document.getElementById('medicine-list');
    const allContainer = document.getElementById('all-medicine-list');
    
    if (medicines.length === 0) {
        todayContainer.innerHTML = '<p>No medicines added yet.</p>';
        allContainer.innerHTML = '<p>No medicines added yet.</p>';
        return;
    }
    
    const today = new Date().toDateString();
    const todayMedicines = medicines.filter(medicine => {
        // For demo purposes, show all medicines
        // In real app, filter by schedule
        return true;
    });
    
    // Display today's medicines
    todayContainer.innerHTML = todayMedicines.map(medicine => `
        <div class="medicine-item">
            <div class="medicine-info">
                <div class="medicine-name">${medicine.name}</div>
                <div class="medicine-details">
                    <i class="fas fa-clock"></i> ${medicine.time} - 
                    <i class="fas fa-pills"></i> ${medicine.dosage} - 
                    <i class="fas fa-calendar"></i> ${medicine.frequency}
                </div>
                <div class="medicine-instructions">${medicine.instructions || 'No specific instructions'}</div>
            </div>
            <div class="medicine-actions-item">
                <button class="btn btn-success" onclick="markMedicineTaken('${medicine.id}')">
                    <i class="fas fa-check"></i> Taken
                </button>
                <button class="btn btn-danger" onclick="deleteMedicine('${medicine.id}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    `).join('');
    
    // Display all medicines
    allContainer.innerHTML = medicines.map(medicine => `
        <div class="medicine-item">
            <div class="medicine-info">
                <div class="medicine-name">${medicine.name}</div>
                <div class="medicine-details">
                    <i class="fas fa-clock"></i> ${medicine.time} - 
                    <i class="fas fa-pills"></i> ${medicine.dosage} - 
                    <i class="fas fa-calendar"></i> ${medicine.frequency}
                </div>
                <div class="medicine-instructions">${medicine.instructions || 'No specific instructions'}</div>
            </div>
            <div class="medicine-actions-item">
                <button class="btn btn-danger" onclick="deleteMedicine('${medicine.id}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    `).join('');
}

function displayMedicinesError() {
    document.getElementById('medicine-list').innerHTML = 
        '<p style="color: red;">Error loading medicines. Please try again.</p>';
    document.getElementById('all-medicine-list').innerHTML = 
        '<p style="color: red;">Error loading medicines.</p>';
}

function openAddMedicineModal() {
    document.getElementById('medicine-modal').style.display = 'block';
}

function closeMedicineModal() {
    document.getElementById('medicine-modal').style.display = 'none';
    document.getElementById('medicine-form').reset();
}

async function handleAddMedicine(event) {
    event.preventDefault();
    
    const medicine = {
        name: document.getElementById('medicine-name').value,
        dosage: document.getElementById('medicine-dosage').value,
        frequency: document.getElementById('medicine-frequency').value,
        time: document.getElementById('medicine-time').value,
        instructions: document.getElementById('medicine-instructions').value
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/medicines`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(medicine)
        });
        
        if (response.ok) {
            closeMedicineModal();
            await loadMedicines();
            showNotification('Medicine added successfully!', 'success');
        } else {
            throw new Error('Failed to add medicine');
        }
    } catch (error) {
        console.error('Error adding medicine:', error);
        showNotification('Failed to add medicine. Please try again.', 'error');
    }
}

async function markMedicineTaken(medicineId) {
    try {
        const response = await fetch(`${API_BASE_URL}/medicines/${medicineId}/taken`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showNotification('Medicine marked as taken!', 'success');
            await loadMedicines();
        } else {
            throw new Error('Failed to mark medicine as taken');
        }
    } catch (error) {
        console.error('Error marking medicine as taken:', error);
        showNotification('Failed to update medicine status.', 'error');
    }
}

// Wellness Functions
async function loadWellnessRecords() {
    try {
        const response = await fetch(`${API_BASE_URL}/wellness`);
        wellnessRecords = await response.json();
        displayWellnessHistory();
        updateDashboard();
    } catch (error) {
        console.error('Error loading wellness records:', error);
        displayWellnessError();
    }
}

function displayWellnessHistory() {
    const container = document.getElementById('wellness-history');
    
    if (wellnessRecords.length === 0) {
        container.innerHTML = '<p>No wellness records yet.</p>';
        return;
    }
    
    const recentRecords = wellnessRecords.slice(0, 5);
    container.innerHTML = recentRecords.map(record => `
        <div class="wellness-record">
            <div class="wellness-record-date">
                <i class="fas fa-calendar"></i> ${formatDate(record.date)}
            </div>
            <div class="wellness-record-data">
                <div class="wellness-record-item">
                    <span class="wellness-record-label">Blood Pressure:</span>
                    <span class="wellness-record-value">${record.bloodPressure}</span>
                </div>
                <div class="wellness-record-item">
                    <span class="wellness-record-label">Heart Rate:</span>
                    <span class="wellness-record-value">${record.heartRate} bpm</span>
                </div>
                <div class="wellness-record-item">
                    <span class="wellness-record-label">Blood Sugar:</span>
                    <span class="wellness-record-value">${record.bloodSugar} mg/dL</span>
                </div>
                <div class="wellness-record-item">
                    <span class="wellness-record-label">Weight:</span>
                    <span class="wellness-record-value">${record.weight} kg</span>
                </div>
                <div class="wellness-record-item">
                    <span class="wellness-record-label">Mood:</span>
                    <span class="wellness-record-value">${record.mood}</span>
                </div>
                ${record.notes ? `
                <div class="wellness-record-item" style="grid-column: 1 / -1;">
                    <span class="wellness-record-label">Notes:</span>
                    <span class="wellness-record-value">${record.notes}</span>
                </div>
                ` : ''}
            </div>
        </div>
    `).join('');
}

function displayWellnessError() {
    document.getElementById('wellness-history').innerHTML = 
        '<p style="color: red;">Error loading wellness records. Please try again.</p>';
}

async function handleWellnessSubmit(event) {
    event.preventDefault();
    
    const wellnessData = {
        bloodPressure: document.getElementById('blood-pressure').value,
        heartRate: document.getElementById('heart-rate').value,
        bloodSugar: document.getElementById('blood-sugar').value,
        weight: document.getElementById('weight').value,
        mood: document.getElementById('mood').value,
        notes: document.getElementById('notes').value
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/wellness`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(wellnessData)
        });
        
        if (response.ok) {
            document.getElementById('wellness-form').reset();
            await loadWellnessRecords();
            showNotification('Wellness data saved successfully!', 'success');
        } else {
            throw new Error('Failed to save wellness data');
        }
    } catch (error) {
        console.error('Error saving wellness data:', error);
        showNotification('Failed to save wellness data. Please try again.', 'error');
    }
}

// Dashboard Functions
function updateDashboard() {
    // Update today's medicine preview
    const todayMedicineContainer = document.getElementById('today-medicine');
    if (medicines.length === 0) {
        todayMedicineContainer.innerHTML = '<p>No medicines scheduled for today.</p>';
    } else {
        const todayCount = medicines.length;
        todayMedicineContainer.innerHTML = `
            <p><strong>${todayCount}</strong> medicine${todayCount !== 1 ? 's' : ''} scheduled for today</p>
        `;
    }
    
    // Update wellness status preview
    const wellnessContainer = document.getElementById('wellness-status');
    const today = new Date().toDateString();
    const todayWellness = wellnessRecords.find(record => 
        new Date(record.date).toDateString() === today
    );
    
    if (todayWellness) {
        wellnessContainer.innerHTML = `
            <p><i class="fas fa-check-circle" style="color: green;"></i> Wellness data recorded today</p>
            <p>Mood: <strong>${todayWellness.mood}</strong></p>
        `;
    } else {
        wellnessContainer.innerHTML = `
            <p><i class="fas fa-exclamation-circle" style="color: orange;"></i> No wellness data today</p>
            <button class="btn btn-primary" onclick="showSection('wellness')" style="margin-top: 10px;">
                Record Now
            </button>
        `;
    }
}

// Medicine Reminder Functions
function checkMedicineReminders() {
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
    
    medicines.forEach(medicine => {
        if (medicine.time === currentTime) {
            showMedicineReminder(medicine);
        }
    });
}

function showMedicineReminder(medicine) {
    const reminderMessage = `Time to take ${medicine.name} (${medicine.dosage})`;
    
    // Show notification
    showNotification(reminderMessage, 'info', 10000); // Show for 10 seconds
    
    // If browser supports it, show system notification
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Medicine Reminder', {
            body: reminderMessage,
            icon: '/images/medicine-icon.png'
        });
    }
}

// Utility Functions
function callEmergency() {
    if (confirm('Are you sure you want to call the emergency number +91 7006273804?')) {
        window.location.href = 'tel:+917006273804';
        showNotification('Calling emergency contact...', 'info');
    }
}

function callContact(phoneNumber) {
    if (confirm(`Are you sure you want to call ${phoneNumber}?`)) {
        window.location.href = `tel:${phoneNumber}`;
        showNotification(`Calling ${phoneNumber}...`, 'info');
    }
}

async function deleteContact(contactId) {
    if (confirm('Are you sure you want to delete this emergency contact?')) {
        try {
            const response = await fetch(`${API_BASE_URL}/contacts/${contactId}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                await loadEmergencyContacts();
                showNotification('Emergency contact deleted successfully!', 'success');
            } else {
                throw new Error('Failed to delete contact');
            }
        } catch (error) {
            console.error('Error deleting contact:', error);
            showNotification('Failed to delete contact. Please try again.', 'error');
        }
    }
}

async function deleteMedicine(medicineId) {
    if (confirm('Are you sure you want to delete this medicine?')) {
        try {
            const response = await fetch(`${API_BASE_URL}/medicines/${medicineId}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                await loadMedicines();
                showNotification('Medicine deleted successfully!', 'success');
            } else {
                throw new Error('Failed to delete medicine');
            }
        } catch (error) {
            console.error('Error deleting medicine:', error);
            showNotification('Failed to delete medicine. Please try again.', 'error');
        }
    }
}

function viewMedicineHistory() {
    // This would open a detailed history view
    showNotification('Medicine history feature coming soon!', 'info');
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function showNotification(message, type = 'info', duration = 5000) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas ${getNotificationIcon(type)}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 400px;
        animation: slideInRight 0.3s ease;
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto remove after duration
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, duration);
}

function getNotificationIcon(type) {
    switch(type) {
        case 'success': return 'fa-check-circle';
        case 'error': return 'fa-exclamation-circle';
        case 'warning': return 'fa-exclamation-triangle';
        default: return 'fa-info-circle';
    }
}

function getNotificationColor(type) {
    switch(type) {
        case 'success': return '#28a745';
        case 'error': return '#dc3545';
        case 'warning': return '#ffc107';
        default: return '#007bff';
    }
}

// Request notification permission on page load
if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
}

// Add CSS animation for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
`;
document.head.appendChild(style);

// Error handling for API calls
window.addEventListener('unhandledrejection', function(event) {
    console.error('Unhandled promise rejection:', event.reason);
    showNotification('An unexpected error occurred. Please try again.', 'error');
});

// Keyboard navigation support
document.addEventListener('keydown', function(event) {
    // Escape key closes modals
    if (event.key === 'Escape') {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
    }
    
    // Ctrl+E for emergency call
    if (event.ctrlKey && event.key === 'e') {
        event.preventDefault();
        callEmergency();
    }
});