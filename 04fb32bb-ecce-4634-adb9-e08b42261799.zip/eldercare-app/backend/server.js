const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Data storage paths
const DATA_DIR = path.join(__dirname, 'data');
const CONTACTS_FILE = path.join(DATA_DIR, 'contacts.json');
const MEDICINES_FILE = path.join(DATA_DIR, 'medicines.json');
const WELLNESS_FILE = path.join(DATA_DIR, 'wellness.json');

// Initialize data directory and files
async function initializeData() {
    try {
        await fs.mkdir(DATA_DIR, { recursive: true });
        
        // Initialize contacts with default emergency contact
        try {
            await fs.access(CONTACTS_FILE);
        } catch {
            const defaultContacts = [
                {
                    id: 'default-emergency',
                    name: 'Primary Emergency Contact',
                    phone: '+91 7006273804',
                    relation: 'Emergency',
                    priority: '1',
                    createdAt: new Date().toISOString()
                }
            ];
            await fs.writeFile(CONTACTS_FILE, JSON.stringify(defaultContacts, null, 2));
        }
        
        // Initialize medicines file
        try {
            await fs.access(MEDICINES_FILE);
        } catch {
            await fs.writeFile(MEDICINES_FILE, JSON.stringify([], null, 2));
        }
        
        // Initialize wellness file
        try {
            await fs.access(WELLNESS_FILE);
        } catch {
            await fs.writeFile(WELLNESS_FILE, JSON.stringify([], null, 2));
        }
        
        console.log('Data files initialized successfully');
    } catch (error) {
        console.error('Error initializing data:', error);
    }
}

// Helper functions
async function readDataFile(filename) {
    try {
        const data = await fs.readFile(filename, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error reading ${filename}:`, error);
        return [];
    }
}

async function writeDataFile(filename, data) {
    try {
        await fs.writeFile(filename, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error(`Error writing ${filename}:`, error);
        return false;
    }
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// API Routes

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Emergency Contacts Routes
app.get('/api/contacts', async (req, res) => {
    try {
        const contacts = await readDataFile(CONTACTS_FILE);
        res.json(contacts);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch contacts' });
    }
});

app.post('/api/contacts', async (req, res) => {
    try {
        const contacts = await readDataFile(CONTACTS_FILE);
        const newContact = {
            id: generateId(),
            ...req.body,
            createdAt: new Date().toISOString()
        };
        
        contacts.push(newContact);
        const success = await writeDataFile(CONTACTS_FILE, contacts);
        
        if (success) {
            res.status(201).json(newContact);
        } else {
            res.status(500).json({ error: 'Failed to save contact' });
        }
    } catch (error) {
        console.error('Error adding contact:', error);
        res.status(500).json({ error: 'Failed to add contact' });
    }
});

app.delete('/api/contacts/:id', async (req, res) => {
    try {
        const contacts = await readDataFile(CONTACTS_FILE);
        const filteredContacts = contacts.filter(contact => contact.id !== req.params.id);
        
        // Prevent deletion of default emergency contact
        if (req.params.id === 'default-emergency') {
            return res.status(400).json({ error: 'Cannot delete default emergency contact' });
        }
        
        const success = await writeDataFile(CONTACTS_FILE, filteredContacts);
        
        if (success) {
            res.json({ message: 'Contact deleted successfully' });
        } else {
            res.status(500).json({ error: 'Failed to delete contact' });
        }
    } catch (error) {
        console.error('Error deleting contact:', error);
        res.status(500).json({ error: 'Failed to delete contact' });
    }
});

// Medicines Routes
app.get('/api/medicines', async (req, res) => {
    try {
        const medicines = await readDataFile(MEDICINES_FILE);
        res.json(medicines);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch medicines' });
    }
});

app.post('/api/medicines', async (req, res) => {
    try {
        const medicines = await readDataFile(MEDICINES_FILE);
        const newMedicine = {
            id: generateId(),
            ...req.body,
            createdAt: new Date().toISOString(),
            takenToday: false
        };
        
        medicines.push(newMedicine);
        const success = await writeDataFile(MEDICINES_FILE, medicines);
        
        if (success) {
            res.status(201).json(newMedicine);
        } else {
            res.status(500).json({ error: 'Failed to save medicine' });
        }
    } catch (error) {
        console.error('Error adding medicine:', error);
        res.status(500).json({ error: 'Failed to add medicine' });
    }
});

app.post('/api/medicines/:id/taken', async (req, res) => {
    try {
        const medicines = await readDataFile(MEDICINES_FILE);
        const medicineIndex = medicines.findIndex(m => m.id === req.params.id);
        
        if (medicineIndex === -1) {
            return res.status(404).json({ error: 'Medicine not found' });
        }
        
        medicines[medicineIndex].takenToday = true;
        medicines[medicineIndex].lastTaken = new Date().toISOString();
        
        const success = await writeDataFile(MEDICINES_FILE, medicines);
        
        if (success) {
            res.json({ message: 'Medicine marked as taken', medicine: medicines[medicineIndex] });
        } else {
            res.status(500).json({ error: 'Failed to update medicine' });
        }
    } catch (error) {
        console.error('Error updating medicine:', error);
        res.status(500).json({ error: 'Failed to update medicine' });
    }
});

app.delete('/api/medicines/:id', async (req, res) => {
    try {
        const medicines = await readDataFile(MEDICINES_FILE);
        const filteredMedicines = medicines.filter(medicine => medicine.id !== req.params.id);
        
        const success = await writeDataFile(MEDICINES_FILE, filteredMedicines);
        
        if (success) {
            res.json({ message: 'Medicine deleted successfully' });
        } else {
            res.status(500).json({ error: 'Failed to delete medicine' });
        }
    } catch (error) {
        console.error('Error deleting medicine:', error);
        res.status(500).json({ error: 'Failed to delete medicine' });
    }
});

// Wellness Routes
app.get('/api/wellness', async (req, res) => {
    try {
        const records = await readDataFile(WELLNESS_FILE);
        // Sort by date, newest first
        records.sort((a, b) => new Date(b.date) - new Date(a.date));
        res.json(records);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch wellness records' });
    }
});

app.post('/api/wellness', async (req, res) => {
    try {
        const records = await readDataFile(WELLNESS_FILE);
        const newRecord = {
            id: generateId(),
            ...req.body,
            date: new Date().toISOString()
        };
        
        records.push(newRecord);
        const success = await writeDataFile(WELLNESS_FILE, records);
        
        if (success) {
            res.status(201).json(newRecord);
        } else {
            res.status(500).json({ error: 'Failed to save wellness record' });
        }
    } catch (error) {
        console.error('Error adding wellness record:', error);
        res.status(500).json({ error: 'Failed to add wellness record' });
    }
});

// Emergency Call Notification Route
app.post('/api/emergency-call', async (req, res) => {
    try {
        const { contactId, reason } = req.body;
        
        // Log the emergency call attempt
        const callLog = {
            id: generateId(),
            contactId,
            reason: reason || 'Emergency',
            timestamp: new Date().toISOString(),
            status: 'initiated'
        };
        
        // In a real app, you would integrate with an SMS/email service
        // For now, we'll just log it
        console.log('Emergency call initiated:', callLog);
        
        // Get contact details
        const contacts = await readDataFile(CONTACTS_FILE);
        const contact = contacts.find(c => c.id === contactId);
        
        if (contact) {
            res.json({
                message: 'Emergency call notification sent',
                contact: contact.name,
                phone: contact.phone,
                log: callLog
            });
        } else {
            res.status(404).json({ error: 'Contact not found' });
        }
    } catch (error) {
        console.error('Error processing emergency call:', error);
        res.status(500).json({ error: 'Failed to process emergency call' });
    }
});

// Medicine Reminder Check Route
app.get('/api/medicine-reminders', async (req, res) => {
    try {
        const medicines = await readDataFile(MEDICINES_FILE);
        const now = new Date();
        const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
        
        const dueMedicines = medicines.filter(medicine => {
            // Check if medicine is due (within 5 minutes window)
            const medicineTime = medicine.time;
            const [medicineHour, medicineMinute] = medicineTime.split(':').map(Number);
            const [currentHour, currentMinute] = currentTime.split(':').map(Number);
            
            const medicineMinutes = medicineHour * 60 + medicineMinute;
            const currentMinutes = currentHour * 60 + currentMinute;
            
            // Due if within 5 minutes
            return Math.abs(medicineMinutes - currentMinutes) <= 5 && !medicine.takenToday;
        });
        
        res.json({
            currentTime,
            dueMedicines: dueMedicines.map(m => ({
                id: m.id,
                name: m.name,
                dosage: m.dosage,
                time: m.time,
                instructions: m.instructions
            }))
        });
    } catch (error) {
        console.error('Error checking medicine reminders:', error);
        res.status(500).json({ error: 'Failed to check reminders' });
    }
});

// Statistics Dashboard Route
app.get('/api/dashboard-stats', async (req, res) => {
    try {
        const contacts = await readDataFile(CONTACTS_FILE);
        const medicines = await readDataFile(MEDICINES_FILE);
        const wellnessRecords = await readDataFile(WELLNESS_FILE);
        
        const today = new Date().toDateString();
        const todayWellness = wellnessRecords.find(record => 
            new Date(record.date).toDateString() === today
        );
        
        const stats = {
            totalContacts: contacts.length,
            totalMedicines: medicines.length,
            todaysMedicines: medicines.filter(m => !m.takenToday).length,
            wellnessRecordedToday: !!todayWellness,
            lastWellnessDate: wellnessRecords.length > 0 ? wellnessRecords[0].date : null,
            emergencyContacts: contacts.filter(c => c.priority === '1').length
        };
        
        res.json(stats);
    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        res.status(500).json({ error: 'Failed to fetch statistics' });
    }
});

// Serve the main application
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
async function startServer() {
    await initializeData();
    
    app.listen(PORT, () => {
        console.log(`🚀 Eldercare Wellness App Server running on port ${PORT}`);
        console.log(`📱 Emergency contact: +91 7006273804`);
        console.log(`🌐 Frontend available at: http://localhost:${PORT}`);
        console.log(`🔗 API available at: http://localhost:${PORT}/api`);
        console.log(`❤️  Taking care of our loved ones...`);
    });
}

// Handle graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    process.exit(0);
});

startServer().catch(console.error);