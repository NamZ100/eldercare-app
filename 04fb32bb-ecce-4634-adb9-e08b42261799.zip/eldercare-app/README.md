# Eldercare Wellness App 🏥❤️

A comprehensive wellness application designed specifically for elderly users, featuring emergency contact management, medicine reminders, and health tracking.

## 🚀 Features

### 🆘 Emergency Contact System
- **Primary Emergency Contact**: Pre-configured with +91 7006273804
- **Add Multiple Contacts**: Easily add family, doctors, and caregivers
- **Priority System**: Organize contacts by importance (Primary, Secondary, Tertiary)
- **One-Click Calling**: Instant emergency call functionality
- **Contact Management**: Add, edit, and delete emergency contacts

### 💊 Medicine Management
- **Medicine Scheduling**: Set up daily, weekly, or as-needed medications
- **Dosage Tracking**: Record medicine dosage and timing
- **Reminder System**: Automated notifications when medicine is due
- **Intake Tracking**: Mark medicines as taken to monitor compliance
- **Special Instructions**: Add notes for taking with food, etc.

### 📊 Wellness Tracking
- **Vital Signs Monitoring**: Track blood pressure, heart rate, blood sugar
- **Weight Management**: Daily weight tracking
- **Mood Monitoring**: Record emotional well-being
- **Health Notes**: Add symptoms or concerns
- **Historical Data**: View wellness trends over time

### 👵 Elderly-Friendly Design
- **Large, Readable Text**: High contrast and clear fonts
- **Simple Navigation**: Easy-to-use interface with large buttons
- **Responsive Design**: Works on tablets, phones, and desktops
- **Accessibility Features**: Screen reader and keyboard navigation support
- **Emergency Quick Access**: Prominent emergency call button

## 🛠️ Technical Features

### Backend
- **Express.js Server**: RESTful API with full CRUD operations
- **JSON Data Storage**: Persistent data storage for contacts, medicines, and wellness records
- **Error Handling**: Comprehensive error management and validation
- **API Endpoints**: Well-documented REST API for all features

### Frontend
- **Modern HTML5/CSS3**: Clean, semantic markup
- **Responsive JavaScript**: Interactive UI with smooth animations
- **Real-time Updates**: Live data synchronization with backend
- **Notification System**: In-app and system notifications for reminders

## 📱 Access the Application

**Live Application**: [https://3000-a95ace85-fcd4-4fa5-89bc-a6395007ee7e.sandbox-service.public.prod.myninja.ai](https://3000-a95ace85-fcd4-4fa5-89bc-a6395007ee7e.sandbox-service.public.prod.myninja.ai)

## 🔧 Setup Instructions

### Prerequisites
- Node.js 14.0.0 or higher
- npm or yarn package manager

### Installation
1. Clone the repository
2. Navigate to the project directory
3. Install dependencies:
   ```bash
   npm install
   ```

### Running the Application
1. Start the server:
   ```bash
   npm start
   ```
2. For development with auto-restart:
   ```bash
   npm run dev
   ```
3. Open your browser and navigate to `http://localhost:3000`

## 📋 API Endpoints

### Emergency Contacts
- `GET /api/contacts` - Get all emergency contacts
- `POST /api/contacts` - Add new emergency contact
- `DELETE /api/contacts/:id` - Delete emergency contact

### Medicines
- `GET /api/medicines` - Get all medicines
- `POST /api/medicines` - Add new medicine
- `POST /api/medicines/:id/taken` - Mark medicine as taken
- `DELETE /api/medicines/:id` - Delete medicine

### Wellness Records
- `GET /api/wellness` - Get wellness records
- `POST /api/wellness` - Add new wellness record

### Dashboard & Utilities
- `GET /api/health` - Health check
- `GET /api/dashboard-stats` - Dashboard statistics
- `GET /api/medicine-reminders` - Check due medicines
- `POST /api/emergency-call` - Log emergency call attempt

## 🎨 Design Philosophy

The application is designed with elderly users in mind:

- **Large Touch Targets**: Buttons and interactive elements are oversized for easy tapping
- **High Contrast Colors**: Strong color contrasts for better visibility
- **Clear Typography**: Large, readable fonts with adequate spacing
- **Simple Workflows**: Minimized steps for common tasks
- **Error Prevention**: Confirmation dialogs for destructive actions
- **Visual Feedback**: Clear indicators for all interactions

## 📞 Emergency Features

- **Default Emergency Contact**: +91 7006273804 is pre-configured
- **Quick Access Button**: Prominent emergency call button on main dashboard
- **Multiple Contacts**: Add family, doctors, and caregivers
- **Priority System**: Organize contacts by urgency
- **One-Tap Calling**: Direct phone integration

## 💾 Data Storage

The application uses JSON file storage in the `backend/data/` directory:
- `contacts.json` - Emergency contact information
- `medicines.json` - Medicine schedules and tracking
- `wellness.json` - Health and wellness records

## 🔒 Security Considerations

- **Input Validation**: All user inputs are validated and sanitized
- **Error Handling**: Comprehensive error management prevents data leaks
- **Secure Defaults**: Default emergency contact is protected from deletion
- **CORS Enabled**: Secure cross-origin resource sharing

## 🌟 Future Enhancements

- **SMS Notifications**: Text message reminders for medicines
- **Doctor Integration**: Connect with healthcare providers
- **Family Portal**: Allow family members to monitor wellness
- **Voice Commands**: Hands-free operation for accessibility
- **Wearable Integration**: Connect with fitness trackers and smartwatches
- **Medication Database**: Integration with pharmacy databases
- **Emergency Services**: Direct connection to emergency services

## 🤝 Contributing

This application is designed to help care for our elderly loved ones. Contributions are welcome for:
- Accessibility improvements
- Additional wellness tracking features
- UI/UX enhancements for elderly users
- New language translations

## 📄 License

MIT License - feel free to use and modify for eldercare purposes.

## ❤️ Made With Love

This application was created to help take care of our elderly loved ones, ensuring they have easy access to emergency contacts and can manage their health independently.

---

*Taking care of those who took care of us.* 🌸